#cargar librerias-----------------
install.packages("spatstat")
library("spatstat")
#

#cargar datos----
ejercicio1 <- data.frame(
  alumnos = c(1,2,3),
  resultados = c(1,3,2)
)

ejercicio1a <- read.table(file.path("/cloud/project", "ejercicio 1.txt"), header = TRUE)
View(ejercicio1a)
head(ejercicio1a)
tail(ejercicio1a)
table(ejercicio1a$Resultado)
informacion <- as.data.frame(table(ejercicio1a$Resultado))
informacion$cum_freq <- cumsum(informacion$Freq)
informacion$cum_perc <- cumsum(informacion$porcentaje)

#visualizar datos-------
plot(c(1,2,3,4), c(2,4,6,8), xlab="x", ylab="y", cex =2, pch = 19, main="grafico de dispersion")
barplot(informacion$Freq, main = "diagrama de barras", col = "blue", names = informacion$var1)
hist(ejercicio1a$Resultado, breaks = 5)
barplot(
  rbind(informacion$Freq, informacion$cum_freq),
  names = informacion[,1],
beside = TRUE,
col = c("red", "black")
)
title(main="ejemplo")
legend("topleft",
       inset=0.2,
       legend=c("Freq", "cum.freq"),
       col = c("red", "black"),
       pch=16)

#estadistica descriptiva------
summary(ejercicio1a$Resultado)
mean(ejercicio1a$Resultado)
median(ejercicio1a$Resultado)

range(ejercicio1a$Resultado)

get_mode <- function(x){
    unique_x <- unique(x)
    return(
      which.max(tabulate(match(x,unique_x)))
         )
}
get_mode(ejercicio1a$Resultado)  

#multivariante-----
pendientes <- matrix(c(4,0,0,0,14,60,2,0,0,20,16,1),
ncol=4,
byrow=TRUE
)
rowSums((pendientes))

#correlaciones------
muestreo <- read.table("BASE DE DATOS PRÁCTICA 1 muestreo.csv", sep = ",", head = FALSE)
x <- muestreo[,1] # primera columna
y <- muestreo[,2] # segunda columna
vegetacion <- muestreo[,3] # tercer columna
roca <- muestreo[,4] # cuarta columna

table(vegetacion,roca)
barplot(table(vegetacion,roca))
plot(x[vegetacion==0],y[vegetacion==0],pch=19,xlab="x",ylab="y", asp=1, xlim=c(0,100))
points(x[vegetacion==1], y[vegetacion==1], pch=19, col="red")
cor(vegetacion,roca)