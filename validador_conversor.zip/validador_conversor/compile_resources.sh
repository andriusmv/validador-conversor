#!/bin/bash
echo "Compilando resources.qrc a resources_rc.py..."
pyrcc5 -o resources_rc.py resources.qrc

if [ $? -ne 0 ]; then
  echo "❌ Error: Asegúrate de que pyrcc5 esté en tu PATH o instalado con 'sudo apt install pyqt5-dev-tools'"
else
  echo "✅ Compilación exitosa."
fi
